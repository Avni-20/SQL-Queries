create table SCHEDULE (
Schedule_id varchar2(3),
travel_date date,
source varchar2(20),
destination varchar2(20),
bus_no number(11),
duration number(11),
constraint pk_schedule primary key (schedule_id) , 
constraint fk_schedule_buses foreign key(bus_no) references buses (bus_no) 
);