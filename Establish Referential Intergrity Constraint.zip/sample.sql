alter table PointofInterest add CONSTRAINT FK_townID foreign key(townID) references town(townID);

