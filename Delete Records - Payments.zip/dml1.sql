delete 
from payments 
where discount_ID='D1';
