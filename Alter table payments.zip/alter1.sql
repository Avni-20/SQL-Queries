alter table payments RENAME COLUMN bd_id TO  booking_id ;
