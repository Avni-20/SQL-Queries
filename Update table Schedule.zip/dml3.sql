update schedule
SET travel_date = travel_date+5
where source='Chennai' AND destination='Bangalore';
